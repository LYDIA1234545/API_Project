
<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\RegisterController;
use App\Http\Controllers\API\ProductController;

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('register', '\App\Http\Controllers\API\RegisterController@register');
Route::post('login', '\App\Http\Controllers\API\RegisterController@login')->name('login');

    Route::post('user', '\App\Http\Controllers\API\ProductController@store');
    Route::get('user/{id}', '\App\Http\Controllers\API\ProductController@show');
    Route::put('user/{id}', '\App\Http\Controllers\API\ProductController@update');
    Route::delete('user/{id}', '\App\Http\Controllers\API\ProductController@destroy');
   
// Route::middleware('auth:api')->group( function () {
//     Route::resource('products', '\App\Http\Controllers\API\ProductController');
// });